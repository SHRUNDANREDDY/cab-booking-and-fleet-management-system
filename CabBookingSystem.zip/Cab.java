public class Cab {

    private int cabNumber;
    private Driver driver;
    private String currentLocation;
    private boolean available;

    Cab next;

    public Cab(int cabNumber, Driver driver, String currentLocation, boolean available) {
        this.cabNumber = cabNumber;
        this.driver = driver;
        this.currentLocation = currentLocation;
        this.available = available;
        this.next = null;
    }

    public int getCabNumber() {
        return cabNumber;
    }

    public void setCabNumber(int cabNumber) {
        this.cabNumber = cabNumber;
    }

    public Driver getDriver() {
        return driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    @Override
    public String toString() {
        return "Cab Number       : " + cabNumber +
                "\nDriver ID        : " + driver.getDriverId() +
                "\nDriver Name      : " + driver.getDriverName() +
                "\nDriver Rating    : " + driver.getDriverRating() +
                "\nCurrent Location : " + currentLocation +
                "\nAvailability     : " + (available ? "Available" : "Occupied");
    }
}