public class Booking {

    private int bookingId;
    private Customer customer;
    private String pickupLocation;
    private String dropLocation;
    private String bookingTime;
    private String tripStatus;
    private double fare;
    private Cab assignedCab;

    Booking next;
    Booking prev;

    public Booking(int bookingId,
                   Customer customer,
                   String pickupLocation,
                   String dropLocation,
                   String bookingTime,
                   String tripStatus,
                   double fare) {

        this.bookingId = bookingId;
        this.customer = customer;
        this.pickupLocation = pickupLocation;
        this.dropLocation = dropLocation;
        this.bookingTime = bookingTime;
        this.tripStatus = tripStatus;
        this.fare = fare;
        this.assignedCab = null;
        this.next = null;
        this.prev = null;
    }

    public int getBookingId() {
        return bookingId;
    }

    public void setBookingId(int bookingId) {
        this.bookingId = bookingId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getDropLocation() {
        return dropLocation;
    }

    public void setDropLocation(String dropLocation) {
        this.dropLocation = dropLocation;
    }

    public String getBookingTime() {
        return bookingTime;
    }

    public void setBookingTime(String bookingTime) {
        this.bookingTime = bookingTime;
    }

    public String getTripStatus() {
        return tripStatus;
    }

    public void setTripStatus(String tripStatus) {
        this.tripStatus = tripStatus;
    }

    public double getFare() {
        return fare;
    }

    public void setFare(double fare) {
        this.fare = fare;
    }

    public Cab getAssignedCab() {
        return assignedCab;
    }

    public void setAssignedCab(Cab assignedCab) {
        this.assignedCab = assignedCab;
    }

    @Override
    public String toString() {

        String cabInfo;

        if (assignedCab == null) {
            cabInfo = "Not Assigned";
        } else {
            cabInfo = assignedCab.getCabNumber() +
                    " (" + assignedCab.getDriver().getDriverName() + ")";
        }

        return "\n----------------------------------------" +
                "\nBooking ID       : " + bookingId +
                "\nCustomer Name    : " + customer.getCustomerName() +
                "\nCustomer ID      : " + customer.getCustomerId() +
                "\nPickup Location  : " + pickupLocation +
                "\nDrop Location    : " + dropLocation +
                "\nBooking Time     : " + bookingTime +
                "\nTrip Status      : " + tripStatus +
                "\nFare             : " + fare +
                "\nAssigned Cab     : " + cabInfo +
                "\n----------------------------------------";
    }
}