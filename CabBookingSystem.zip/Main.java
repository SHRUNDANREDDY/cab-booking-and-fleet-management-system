public class Main {

    public static void main(String[] args) {


        CabBookingSystem system =
                new CabBookingSystem();



        Driver d1 =
                new Driver(
                        101,
                        "Arun",
                        4.5
                );


        Driver d2 =
                new Driver(
                        102,
                        "Rahul",
                        4.7
                );


        Driver d3 =
                new Driver(
                        103,
                        "Vijay",
                        4.3
                );


        Driver d4 =
                new Driver(
                        104,
                        "Kiran",
                        4.8
                );



        Cab c1 =
                new Cab(
                        1001,
                        d1,
                        "Airport",
                        true
                );


        Cab c2 =
                new Cab(
                        1002,
                        d2,
                        "Railway Station",
                        true
                );


        Cab c3 =
                new Cab(
                        1003,
                        d3,
                        "Bus Stand",
                        true
                );


        Cab c4 =
                new Cab(
                        1004,
                        d4,
                        "City Center",
                        true
                );



        system.addCab(c1);

        system.addCab(c2);

        system.addCab(c3);

        system.addCab(c4);



        system.menu();

    }

}