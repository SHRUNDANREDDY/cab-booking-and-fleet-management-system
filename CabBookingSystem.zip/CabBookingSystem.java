import java.util.Scanner;

public class CabBookingSystem {

    private BookingList bookingList;
    private Fleet fleet;
    private RideHistory rideHistory;
    private Reports reports;

    private Scanner scanner;

    public CabBookingSystem() {

        bookingList = new BookingList();
        fleet = new Fleet();
        rideHistory = new RideHistory();

        reports = new Reports(
                bookingList,
                fleet,
                rideHistory
        );

        scanner = new Scanner(System.in);
    }


    public void addCab(Cab cab) {

        fleet.addCab(cab);
    }


    public void createBooking() {

        System.out.print("Enter Booking ID: ");
        int id = scanner.nextInt();


        System.out.print("Enter Customer ID: ");
        int customerId = scanner.nextInt();

        scanner.nextLine();


        System.out.print("Enter Customer Name: ");
        String name = scanner.nextLine();


        System.out.print("Enter Phone Number: ");
        String phone = scanner.nextLine();


        Customer customer =
                new Customer(
                        customerId,
                        name,
                        phone
                );


        System.out.print("Enter Pickup Location: ");
        String pickup = scanner.nextLine();


        System.out.print("Enter Drop Location: ");
        String drop = scanner.nextLine();


        System.out.print("Enter Booking Time: ");
        String time = scanner.nextLine();


        System.out.print("Enter Fare: ");
        double fare = scanner.nextDouble();



        Booking booking =
                new Booking(
                        id,
                        customer,
                        pickup,
                        drop,
                        time,
                        "Pending",
                        fare
                );


        Cab cab = fleet.allocateCab();


        if(cab != null) {

            booking.setAssignedCab(cab);

            booking.setTripStatus(
                    "Allocated"
            );

            System.out.println(
                    "Cab Assigned Successfully"
            );

        }

        else {

            System.out.println(
                    "No cab available currently"
            );
        }


        bookingList.insertAtEnd(booking);

        System.out.println(
                "Booking Created Successfully"
        );
    }



    public void completeRide() {


        System.out.print(
                "Enter Booking ID: "
        );

        int id = scanner.nextInt();



        Booking booking =
                bookingList.searchBookingById(id);



        if(booking == null) {

            System.out.println(
                    "Booking not found"
            );

            return;
        }



        booking.setTripStatus(
                "Completed"
        );


        CompletedRide ride =
                new CompletedRide(
                        booking
                );


        rideHistory.addCompletedRide(
                ride
        );



        if(booking.getAssignedCab()!=null) {

            fleet.releaseCab(
                    booking.getAssignedCab()
                            .getCabNumber()
            );
        }


        bookingList.deleteBooking(id);



        System.out.println(
                "Ride completed successfully"
        );

    }




    public void cancelBooking() {


        System.out.print(
                "Enter Booking ID: "
        );


        int id = scanner.nextInt();



        Booking booking =
                bookingList.searchBookingById(id);



        if(booking == null) {

            System.out.println(
                    "Booking not found"
            );

            return;
        }



        if(booking.getAssignedCab()!=null) {

            fleet.releaseCab(
                    booking.getAssignedCab()
                    .getCabNumber()
            );
        }



        bookingList.deleteBooking(id);



        System.out.println(
                "Booking cancelled successfully"
        );
    }





    public void searchBooking() {


        System.out.print(
                "Enter Booking ID: "
        );


        int id = scanner.nextInt();



        Booking booking =
                bookingList.searchBookingById(id);



        if(booking != null) {

            System.out.println(
                    booking
            );

        }

        else {

            System.out.println(
                    "Booking not found"
            );
        }
    }





    public void displayBookings() {

        bookingList.displayAllBookings();
    }



    public void displayHistory() {

        rideHistory.displayHistory();
    }



    public void displayFleet() {

        fleet.displayFleet();
    }



    public void showReports() {

        reports.generateSystemSummary();
    }



    public void menu() {


        int choice;


        do {


            System.out.println(
                    "\n===== CAB BOOKING SYSTEM ====="
            );


            System.out.println(
                    "1. Create Booking"
            );

            System.out.println(
                    "2. Complete Ride"
            );

            System.out.println(
                    "3. Cancel Booking"
            );

            System.out.println(
                    "4. Search Booking"
            );

            System.out.println(
                    "5. Display Active Bookings"
            );

            System.out.println(
                    "6. Display Ride History"
            );

            System.out.println(
                    "7. Display Fleet"
            );

            System.out.println(
                    "8. Reports"
            );

            System.out.println(
                    "0. Exit"
            );


            System.out.print(
                    "Enter choice: "
            );


            choice = scanner.nextInt();



            switch(choice) {


                case 1:

                    createBooking();

                    break;



                case 2:

                    completeRide();

                    break;



                case 3:

                    cancelBooking();

                    break;



                case 4:

                    searchBooking();

                    break;



                case 5:

                    displayBookings();

                    break;



                case 6:

                    displayHistory();

                    break;



                case 7:

                    displayFleet();

                    break;



                case 8:

                    showReports();

                    break;



                case 0:

                    System.out.println(
                            "Exiting System"
                    );

                    break;



                default:

                    System.out.println(
                            "Invalid choice"
                    );
            }


        } while(choice != 0);

    }

}