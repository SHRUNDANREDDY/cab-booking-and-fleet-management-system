public class Fleet {

    private Cab head;
    private Cab current;
    private int size;

    public Fleet() {
        head = null;
        current = null;
        size = 0;
    }


    public boolean isEmpty() {
        return head == null;
    }


    public int getSize() {
        return size;
    }


    public void addCab(Cab cab) {

        if (cab == null) {
            return;
        }

        if (isEmpty()) {

            head = cab;
            cab.next = head;
            current = head;

        } else {

            Cab temp = head;

            while (temp.next != head) {
                temp = temp.next;
            }

            temp.next = cab;
            cab.next = head;
        }

        size++;
    }


    public void displayFleet() {

        if (isEmpty()) {
            System.out.println("No cabs available.");
            return;
        }

        Cab temp = current;

        do {

            System.out.println(temp);

            temp = temp.next;

        } while (temp != current);
    }


    public Cab getHead() {
        return head;
    }


    public Cab getCurrent() {
        return current;
    }
        public Cab allocateCab() {

        if (isEmpty()) {
            return null;
        }

        Cab start = current;

        do {

            if (current.isAvailable()) {

                current.setAvailable(false);

                Cab allocatedCab = current;

                current = current.next;

                return allocatedCab;
            }

            current = current.next;

        } while (current != start);


        return null;
    }


    public boolean releaseCab(int cabNumber) {

        Cab cab = searchCabByNumber(cabNumber);

        if (cab == null) {
            return false;
        }

        cab.setAvailable(true);

        return true;
    }


    public boolean removeCab(int cabNumber) {

        if (isEmpty()) {
            return false;
        }


        Cab currentCab = head;
        Cab previousCab = null;


        do {

            if (currentCab.getCabNumber() == cabNumber) {


                if (size == 1) {

                    head = null;
                    current = null;

                }

                else if (currentCab == head) {


                    Cab last = head;

                    while (last.next != head) {
                        last = last.next;
                    }


                    head = head.next;

                    last.next = head;


                    if (current == currentCab) {
                        current = head;
                    }

                }

                else {


                    previousCab.next = currentCab.next;


                    if (current == currentCab) {
                        current = currentCab.next;
                    }

                }


                currentCab.next = null;

                size--;

                return true;
            }


            previousCab = currentCab;
            currentCab = currentCab.next;


        } while (currentCab != head);


        return false;
    }


    public Cab searchCabByNumber(int cabNumber) {


        if (isEmpty()) {
            return null;
        }


        Cab temp = head;


        do {


            if (temp.getCabNumber() == cabNumber) {

                return temp;
            }


            temp = temp.next;


        } while (temp != head);


        return null;
    }


    public Cab searchCabByDriverId(int driverId) {


        if (isEmpty()) {
            return null;
        }


        Cab temp = head;


        do {


            if (temp.getDriver().getDriverId() == driverId) {

                return temp;
            }


            temp = temp.next;


        } while (temp != head);



        return null;
    }
}