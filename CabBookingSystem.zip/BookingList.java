public class BookingList {

    private Booking head;
    private Booking tail;
    private int size;

    public BookingList() {
        head = null;
        tail = null;
        size = 0;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public int getSize() {
        return size;
    }

    public void insertAtBeginning(Booking booking) {

        if (booking == null) {
            return;
        }

        booking.next = null;
        booking.prev = null;

        if (isEmpty()) {
            head = booking;
            tail = booking;
        } else {
            booking.next = head;
            head.prev = booking;
            head = booking;
        }

        size++;
    }

    public void insertAtEnd(Booking booking) {

        if (booking == null) {
            return;
        }

        booking.next = null;
        booking.prev = null;

        if (isEmpty()) {
            head = booking;
            tail = booking;
        } else {
            tail.next = booking;
            booking.prev = tail;
            tail = booking;
        }

        size++;
    }

    public boolean insertAfterBooking(int bookingId, Booking newBooking) {

        if (newBooking == null) {
            return false;
        }

        Booking current = head;

        while (current != null) {

            if (current.getBookingId() == bookingId) {

                newBooking.next = current.next;
                newBooking.prev = current;

                if (current.next != null) {
                    current.next.prev = newBooking;
                } else {
                    tail = newBooking;
                }

                current.next = newBooking;

                size++;
                return true;
            }

            current = current.next;
        }

        return false;
    }

    public Booking searchBookingById(int bookingId) {

        Booking current = head;

        while (current != null) {

            if (current.getBookingId() == bookingId) {
                return current;
            }

            current = current.next;
        }

        return null;
    }

    public Booking getHead() {
        return head;
    }

    public Booking getTail() {
        return tail;
    }
        public boolean deleteBooking(int bookingId) {

        if (isEmpty()) {
            return false;
        }

        Booking current = head;

        while (current != null) {

            if (current.getBookingId() == bookingId) {

                if (head == tail) {
                    head = null;
                    tail = null;
                }

                else if (current == head) {
                    head = head.next;
                    head.prev = null;
                }

                else if (current == tail) {
                    tail = tail.prev;
                    tail.next = null;
                }

                else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                }

                current.next = null;
                current.prev = null;

                size--;

                return true;
            }

            current = current.next;
        }

        return false;
    }

    public boolean updateBooking(int bookingId,
                                 String pickup,
                                 String drop,
                                 String bookingTime,
                                 String status,
                                 double fare) {

        Booking booking = searchBookingById(bookingId);

        if (booking == null) {
            return false;
        }

        booking.setPickupLocation(pickup);
        booking.setDropLocation(drop);
        booking.setBookingTime(bookingTime);
        booking.setTripStatus(status);
        booking.setFare(fare);

        return true;
    }

    public void searchBookingsByCustomer(int customerId) {

        Booking current = head;

        boolean found = false;

        while (current != null) {

            if (current.getCustomer().getCustomerId() == customerId) {

                System.out.println(current);

                found = true;
            }

            current = current.next;
        }

        if (!found) {
            System.out.println("No bookings found.");
        }
    }

    public int getTotalBookings() {
        return size;
    }

    public void displayAllBookings() {

        if (isEmpty()) {
            System.out.println("No active bookings.");
            return;
        }

        Booking current = head;

        while (current != null) {

            System.out.println(current);

            current = current.next;
        }
    }

    public void displayReverseBookings() {

        if (isEmpty()) {
            System.out.println("No active bookings.");
            return;
        }

        Booking current = tail;

        while (current != null) {

            System.out.println(current);

            current = current.prev;
        }
    }
        public void sortByFare() {

        if (head == null || head.next == null) {
            return;
        }

        head = mergeSortFare(head);

        tail = head;

        while (tail.next != null) {
            tail = tail.next;
        }
    }


    private Booking mergeSortFare(Booking start) {

        if (start == null || start.next == null) {
            return start;
        }


        Booking middle = getMiddle(start);

        Booking secondHalf = middle.next;


        middle.next = null;


        if (secondHalf != null) {
            secondHalf.prev = null;
        }


        Booking left = mergeSortFare(start);

        Booking right = mergeSortFare(secondHalf);


        return mergeFare(left, right);
    }



    private Booking mergeFare(Booking first, Booking second) {


        if (first == null) {
            return second;
        }


        if (second == null) {
            return first;
        }


        Booking result;


        if (first.getFare() <= second.getFare()) {


            result = first;


            result.next =
                    mergeFare(first.next, second);


            if (result.next != null) {

                result.next.prev = result;
            }


            result.prev = null;


        } else {


            result = second;


            result.next =
                    mergeFare(first, second.next);


            if (result.next != null) {

                result.next.prev = result;
            }


            result.prev = null;

        }


        return result;
    }



    private Booking getMiddle(Booking start) {


        if (start == null) {
            return null;
        }


        Booking slow = start;

        Booking fast = start;



        while (fast.next != null &&
               fast.next.next != null) {


            slow = slow.next;

            fast = fast.next.next;
        }


        return slow;
    }
        public void sortByCustomerName() {

        if (head == null || head.next == null) {
            return;
        }


        head = mergeSortCustomer(head);


        tail = head;


        while (tail.next != null) {

            tail = tail.next;
        }
    }



    private Booking mergeSortCustomer(Booking start) {


        if (start == null || start.next == null) {

            return start;
        }


        Booking middle = getMiddle(start);


        Booking secondHalf = middle.next;


        middle.next = null;


        if (secondHalf != null) {

            secondHalf.prev = null;
        }



        Booking left =
                mergeSortCustomer(start);



        Booking right =
                mergeSortCustomer(secondHalf);



        return mergeCustomer(left, right);
    }





    private Booking mergeCustomer(Booking first,
                                  Booking second) {



        if (first == null) {

            return second;
        }


        if (second == null) {

            return first;
        }



        Booking result;



        if (compareCustomerName(first, second) <= 0) {



            result = first;


            result.next =
                    mergeCustomer(first.next, second);



            if (result.next != null) {

                result.next.prev = result;
            }


            result.prev = null;



        } else {



            result = second;


            result.next =
                    mergeCustomer(first, second.next);



            if (result.next != null) {

                result.next.prev = result;
            }


            result.prev = null;
        }



        return result;
    }





    private int compareCustomerName(Booking first,
                                    Booking second) {


        return first.getCustomer()
                .getCustomerName()
                .compareToIgnoreCase(
                        second.getCustomer()
                        .getCustomerName()
                );
    }
        public void sortByBookingTime() {

        if (head == null || head.next == null) {
            return;
        }

        head = mergeSortTime(head);

        tail = head;

        while (tail.next != null) {
            tail = tail.next;
        }
    }


    private Booking mergeSortTime(Booking start) {

        if (start == null || start.next == null) {
            return start;
        }


        Booking middle = getMiddle(start);

        Booking secondHalf = middle.next;


        middle.next = null;


        if (secondHalf != null) {
            secondHalf.prev = null;
        }


        Booking left = mergeSortTime(start);

        Booking right = mergeSortTime(secondHalf);


        return mergeTime(left, right);
    }



    private Booking mergeTime(Booking first, Booking second) {


        if (first == null) {
            return second;
        }


        if (second == null) {
            return first;
        }


        Booking result;


        if (compareTime(first, second) <= 0) {


            result = first;


            result.next = mergeTime(first.next, second);


            if (result.next != null) {
                result.next.prev = result;
            }


            result.prev = null;


        } else {


            result = second;


            result.next = mergeTime(first, second.next);


            if (result.next != null) {
                result.next.prev = result;
            }


            result.prev = null;

        }


        return result;
    }



    private int compareTime(Booking first, Booking second) {


        return first.getBookingTime()
                .compareTo(second.getBookingTime());

    }
}