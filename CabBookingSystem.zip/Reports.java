public class Reports {

    private BookingList bookingList;
    private Fleet fleet;
    private RideHistory rideHistory;


    public Reports(BookingList bookingList,
                   Fleet fleet,
                   RideHistory rideHistory) {

        this.bookingList = bookingList;
        this.fleet = fleet;
        this.rideHistory = rideHistory;
    }


    public void generateActiveBookingReport() {

        System.out.println("\n===== ACTIVE BOOKING REPORT =====");

        bookingList.displayAllBookings();

        System.out.println(
                "Total Active Bookings : "
                + bookingList.getTotalBookings()
        );
    }


    public void generateCompletedRideReport() {

        System.out.println("\n===== COMPLETED RIDE REPORT =====");

        rideHistory.displayHistory();

        System.out.println(
                "Total Completed Rides : "
                + rideHistory.countCompletedRides()
        );
    }


    public void generateAvailableCabReport() {

        System.out.println("\n===== AVAILABLE CAB REPORT =====");

        if (fleet.isEmpty()) {

            System.out.println("No cabs available.");

            return;
        }


        Cab current = fleet.getHead();


        do {

            if (current.isAvailable()) {

                System.out.println(current);
            }


            current = current.next;


        } while (current != fleet.getHead());

    }


    public void generateOccupiedCabReport() {

        System.out.println("\n===== OCCUPIED CAB REPORT =====");


        if (fleet.isEmpty()) {

            System.out.println("No cabs available.");

            return;
        }


        Cab current = fleet.getHead();


        do {

            if (!current.isAvailable()) {

                System.out.println(current);
            }


            current = current.next;


        } while (current != fleet.getHead());

    }


    public void generateSystemSummary() {


        System.out.println("\n===== SYSTEM SUMMARY =====");


        System.out.println(
                "Active Bookings : "
                + bookingList.getTotalBookings()
        );


        System.out.println(
                "Completed Rides : "
                + rideHistory.countCompletedRides()
        );


        System.out.println(
                "Total Cabs      : "
                + fleet.getSize()
        );

    }

}