public class RideHistory {

    private CompletedRide head;
    private CompletedRide tail;
    private int size;


    public RideHistory() {

        head = null;
        tail = null;
        size = 0;
    }


    public boolean isEmpty() {

        return head == null;
    }


    public int getSize() {

        return size;
    }


    public void addCompletedRide(CompletedRide ride) {


        if (ride == null) {
            return;
        }


        ride.next = null;


        if (isEmpty()) {

            head = ride;
            tail = ride;

        } else {

            tail.next = ride;
            tail = ride;
        }


        size++;
    }


    public CompletedRide searchRideByBookingId(int bookingId) {


        CompletedRide current = head;


        while (current != null) {


            if (current.getBooking().getBookingId() == bookingId) {

                return current;
            }


            current = current.next;
        }


        return null;
    }


    public void searchRideByCustomerId(int customerId) {


        CompletedRide current = head;

        boolean found = false;


        while (current != null) {


            if (current.getBooking()
                    .getCustomer()
                    .getCustomerId() == customerId) {


                System.out.println(current);

                found = true;
            }


            current = current.next;
        }


        if (!found) {

            System.out.println("No completed rides found.");
        }
    }


    public void displayHistory() {


        if (isEmpty()) {

            System.out.println("No completed rides available.");

            return;
        }


        CompletedRide current = head;


        while (current != null) {


            System.out.println(current);


            current = current.next;
        }
    }


    public int countCompletedRides() {

        return size;
    }


    public CompletedRide getHead() {

        return head;
    }

}