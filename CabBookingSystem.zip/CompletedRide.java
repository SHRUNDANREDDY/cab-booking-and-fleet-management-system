public class CompletedRide {

    private Booking booking;

    CompletedRide next;

    public CompletedRide(Booking booking) {
        this.booking = booking;
        this.next = null;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    @Override
    public String toString() {
        return booking.toString();
    }
}