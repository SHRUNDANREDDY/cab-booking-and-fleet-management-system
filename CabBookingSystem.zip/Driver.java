public class Driver {

    private int driverId;
    private String driverName;
    private double driverRating;

    public Driver(int driverId, String driverName, double driverRating) {
        this.driverId = driverId;
        this.driverName = driverName;
        this.driverRating = driverRating;
    }

    public int getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public double getDriverRating() {
        return driverRating;
    }

    public void setDriverRating(double driverRating) {
        this.driverRating = driverRating;
    }

    @Override
    public String toString() {
        return "Driver ID        : " + driverId +
                "\nDriver Name      : " + driverName +
                "\nDriver Rating    : " + driverRating;
    }
}